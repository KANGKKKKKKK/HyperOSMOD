settings put global development_settings_enabled 1
am start -a com.android.settings.APPLICATION_DEVELOPMENT_SETTINGS
exit 0